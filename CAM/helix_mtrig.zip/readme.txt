art001.pho: Top Copper
art002.pho: Inner Layer 2
art003.pho: Inner Layer 3
art004.pho: Inner Layer 4
art005.pho: Inner Layer 5
art006.pho: Inner Layer 6
art007.pho: Inner Layer 7
sst001126.pho: Top Silkscreen
ssb008129.pho: Bottom Silkscreen
sm001121.pho: Top Soldermask
sm008128.pho: Bottom Soldermask

Layer stackup should be 5.9/9/7.3/5.1/7.3/9/5.9.
Contact allison.122@osu.edu with any questions.